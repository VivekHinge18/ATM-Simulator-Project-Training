
def about():
    print("------------ATM Project------------")
    print(
'''This project was coded by - 
    - Shruti Minocha
    - Rishi Pongade
    - Vivek Hinge
    - Satyajit Dey
            
Guided By - Mr. Aditya Kumar Ojha''')
